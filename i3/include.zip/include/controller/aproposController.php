<?php 
    // verifie


    include("view/page/apropos.php");
?>
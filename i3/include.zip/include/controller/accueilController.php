<?php 
    // verifie


    include("view/page/accueil.php");
?>
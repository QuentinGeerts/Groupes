<?php 
    // verifie


    include("view/page/contact.php");
?>
<div class="container">
    <div class="jumbotron">
        <h1>Mon super site</h1>
    </div>
</div>
<div class="container">
    <h2>Afficher les personnes</h2>
    <table class="table table-striped">
        <?= $table; ?> 
    </table>
</div>
<script>
    read.classList.add("active");
</script>

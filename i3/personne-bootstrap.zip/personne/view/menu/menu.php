<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="?section=accueil">Personnes</a>
    </div>
    <ul class="nav navbar-nav">
      <li id="read"><a href="?section=read">Accueil</a></li>
      <li id="create"><a href="?section=create">Ajouter</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="?section=connexion"><span class="glyphicon glyphicon-user"></span> Connexion</a></li>
      <li><a href="?section=deconnexion"><span class="glyphicon glyphicon-log-in"></span> Déconnexion</a></li>
    </ul>
  </div>
</nav>
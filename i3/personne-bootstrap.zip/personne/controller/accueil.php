<?php 
    require_once("view/page/accueil.php");
?>
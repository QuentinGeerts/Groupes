<nav>
    <ul>
        <li><a href="?section=read">Afficher</a></li>
        <li><a href="?section=create">Ajouter</a></li>
    </ul>
</nav>
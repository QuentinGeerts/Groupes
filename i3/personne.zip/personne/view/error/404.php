<h2>Page non trouvée</h2>
<p>Cliquer pour revenir à la page d'<a href="">accueil</a></p>
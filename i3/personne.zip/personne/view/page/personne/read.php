<h2>Afficher les personnes</h2>
<table>
    <?= $table; ?> 
</table>
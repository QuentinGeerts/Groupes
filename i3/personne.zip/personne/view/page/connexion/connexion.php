<h2>Connexion</h2>
<form action="#" method="post">
    <label for="login">Login :</label>
    <input type="text" name="login" id="login"><br>
    <label for="mdp">Mot de passe :</label>
    <input type="text" name="mdp" id="mdp"><br>
    <input type="submit" value="Connexion">
</form>
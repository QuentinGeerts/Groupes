<?php

require_once('view/html/head.php');

require_once('view/html/menu.php');

require_once('controller/router.php');

require_once('view/html/footer.php');

?>
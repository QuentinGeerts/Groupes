<h1>Page non trouvée.</h1>
<p>La page que vous essayé d'accéder (<?= $_GET['section'] ?>) n'existe pas ou n'a pas été trouvée.</p>
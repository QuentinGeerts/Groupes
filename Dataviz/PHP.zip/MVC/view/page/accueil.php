<h1>Accueil</h1>

<table>
    <thead>
        <td>id</td>
        <td>Nom</td>
    </thead>

    <tbody>
        <?= $table; ?>
    </tbody>
</table>
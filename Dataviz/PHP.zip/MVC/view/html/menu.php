<ul>
    <li><a href="?section=accueil">Accueil</a></li>
    <li><a href="?section=apropos">A propos</a></li>
    <li><a href="?section=contact">Contact</a></li>
</ul>
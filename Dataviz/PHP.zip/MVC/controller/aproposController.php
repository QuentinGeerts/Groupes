<?php

// Récupération des différentes données


require_once('view/page/apropos.php');

?>
<ul>
    <li><a href="create.php">Create</a></li>
    <li><a href="getBoissons.php">Read1</a></li>
    <li><a href="getBoissons2.php">Read2</a></li>
    <li><a href="update.php">Update</a></li>
    <li><a href="delete.php">Delete</a></li>
</ul>
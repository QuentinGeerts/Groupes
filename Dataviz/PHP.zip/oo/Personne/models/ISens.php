<?php

interface ISens {
    
    public function voir();
    public function entendre();

}

?>
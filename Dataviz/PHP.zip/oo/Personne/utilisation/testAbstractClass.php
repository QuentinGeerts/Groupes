<?php

require_once('../models/Personne.php');

$p = new Personne("P1", "P1", "2021-09-23");

$p->sePresenter();


?>